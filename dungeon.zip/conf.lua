function love.conf(t)
	t.title = "Dungeons"
	t.version = "0.10.1";
	t.window.width = 1280;
	t.window.height = 720;


	t.console = true;
end